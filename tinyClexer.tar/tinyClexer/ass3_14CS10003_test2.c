#include<stdio.h>
#include<math.h>

//single line comment

/* multi
 line

 comment
 ****/

//keywords
auto
break
case
char
const
continue
default
do
double
else
enum
extern
float
for
goto
if
inline
int
long
register
restrict
return
short
signed
sizeof
static
struct
switch
typedef
union
unsigned
void
volatile
while
_Bool
_Complex
_Imaginary


int var=874;
float y=512.6;
y=.6;
y=12e13;

string greetings = "Welcome";
"Testing String"

char charvar = 'It\'s a char constant\n';
9812 /* random integer */

if(a==b){
	printf("a equals b");

}
else {
	printf("a is not equal to b\n");
}


'a' // testing char

for(i=0;i<=n;i++){
	printf("i");
	j+=5;
	k--;
	m/=5;

}
//punctuators
[
++
/
?
=
,
]
(
{ } . ->
* + - ~ !
% << >> < > <= >=
: ; ...
*= /= %= += -= <<=
#
--
)
&
==
>>=
!=
&=
^
|
^=
&&
||
|=

enum days{"mon","tues","sun"};
//different floats
float a=19e+23
21e+7
4.
.34
98.445
